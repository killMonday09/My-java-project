package com.szxs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmwPayConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
